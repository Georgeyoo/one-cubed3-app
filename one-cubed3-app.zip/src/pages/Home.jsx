export default function Home() {
  return (
    <div>
      <h1>Welcome to Cubed3</h1>
      <p>This is a placeholder for the landing page.</p>
    </div>
  );
}
